#!/bin/bash
# -----------------------------------------------------------------
#  FFmpeg process DVD-ripped files (VOB, IFO) 
# 
#  16 episodes (S01E01, S02E01-05, S03E01-10) across 8 VOB files.
#
#  VTS_01_0.IFO contains the chapters' info (timestamps).
# ----------------------------------------------------------------
# Stream-process all VOB per chapter or episode 
# Timestamps (log files) previously extracted from VTS_01_0.IFO 
# using MediaInfo.exe (GUI|CLI; both worked). 
foo() {
    [[ $2 ]] && { _to="-to $2"; } || { _to= ; } 
    ffmpeg -hide_banner -i "./$_ALL_VOB" -ss $1 $_to -c copy ./${_mode}/VTS_01_${1//:/.}.VOB
}
streamArgs() { 
    _foo_MINARGS=1; _N=1
    (( $# < $_foo_MINARGS )) && return
    ( foo "$@" & ); shift $_N; $FUNCNAME "$@" 
}
export -f streamArgs 
export -f foo
#_mode='ch' # Uncomment to extract per chapter
_mode='ep' # Uncomment to extract per episode
export _mode
export _IFO_LOG="VTS_01_0.IFO.${_mode}.log"
export _ALL_VOB='VTS_01_ALL.VOB'

# ===  START VOB PROCESSing  ===

clear; printf "\n %s %s"  'Select: Extract [1] or Rename [2] ALL per' "'${_mode}' ...  " ; read _process 
case ${_process,,} in 

    "1" | "extract")
        # concat all VOB
        [[ ! -f "$_ALL_VOB" ]] && cat VTS_01_{1..8}.VOB > "$_ALL_VOB"
        # process all VOB files per log (per mode; chapter| or episode timestamps) 
        [[ -d "$_mode" ]] || mkdir "$_mode"
        cat "$_IFO_LOG" | gawk '{print $1}' | xargs /bin/bash -c 'streamArgs "$0" "$@"'
    ;;

    "2" | "rename") 
        # rename episode files per names @ log; only if 'ep' mode
        [[ "$_mode" == 'ep' ]] && {
            cat "$_IFO_LOG" | gawk '{print "VTS_01_" $1 ".VOB  " $5}' | sed 's/:/./g' | xargs -n 2 /bin/bash -c 'mv "./${_mode}/$0" "./${_mode}/$1.VOB"' 
        
    ;;
esac
printf "\n %s %s"  '... DONE per' "'${_mode}' mode. (Press ENTER key to end.)  " ; read  

# ===  END VOB PROCESSing  ===
exit 

# --------------------------------------------------------------
#  How to extract chapter/episode timestamps from IFO file ...
# --------------------------------------------------------------

# WANT to read/extract Chapter timestamps from .IFO file of ripped-DVD 
mediainfo.exe 'VTS_01_0.IFO'  # SOLVEs ! 
# ... a GUI/CLI tool; GUI included in K-Lite Codec Pack (with MPc-HC mod) 
# MPc-HC (K-Lite mod) shows chapters & timestamps (uses mediainfo.exe) 

mplayer.exe
# Supposedly, mplayer can extract the data, but it failed  ...
    # https://stackoverflow.com/questions/12239235/how-to-obtain-titles-and-chapters-information-in-dvd
    c:\mklink /j r:\dvd "%CD%"
    mplayer S:\dvd\VTS_01_0.IFO  
    # ... works @ cmd.exe, but plays video and shows no chapter info. 
    # Do NOT run from mintty terminal (causes Windows GUI freeze/BSOD)

    PATH="/r/mplayer:$PATH"
    # none of this works; some cause BSOD if run from mintty (perhaps run X11 to cure) ...
    mplayer.exe -identify -frames 0 '/r/dvd/VTS_01_0.IFO' 2>/dev/null | grep 'CHAPTERS:'
    mplayer.exe -endpos 0 -identify -frames 0 "/r/dvd/VTS_01_0.IFO" 2>/dev/null | grep CHAPTERS: 
    mplayer.exe -endpos 0 -identify -frames 0 dvd:// -dvd-device /r/dvd
    mplayer.exe -endpos 0 -vo null -ao null VTS_01_0.IFO

# --------------------------------------------------------------
#  Primitives ...
# --------------------------------------------------------------

# Concat all VOB, except the menus, per brace-expansion (globbing). 
cat VTS_01_{1..8}.VOB > 'VTS_01_ALL.VOB'

# Concat + transcode MPEG-2 (VOB) => MPEG-4 per QSV HW acceleration
cat VTS_01_{1..8}.VOB | ffmpeg -hwaccel qsv -c:v mpeg2_qsv -i - \
-c:v h264_qsv -preset:v slow -global_quality 21 -c:a copy 'VTS_01_ALL.mp4'
# `-r 29.97` to change FPS

# Mux A/V
ffmpeg -i Video.mp4 -i Audio.m4a -c copy Muxed.mp4

# Mux A/V; mute V
ffmpeg -i Video.mp4 -i Audio.wav \
-c:v copy -c:a aac -strict experimental \
-map 0:v:0 -map 1:a:0 Muxed.mp4

# Mux A/V; mute V; sources differ in lengh/speed/FPS
# Use Presentation TimeStamp (PTS) filter; changes that of each video frame.
# Finding the stretch-factor, e.g., @ 'Aeon Flux S02E01 Gravity'; 
# 'mpg' (audio) vs. 'VOB' (video) sets: 
#   FPS ratio: (29.97/25) = 1.1988
#   A/V ratio: (3.15 min / 3.08 min) = 1.023
#   ... neither ratios result in video length equal to that of audio.
# The factor that worked here was 1.035, found by trial and error: 
ffmpeg -i video.mp4 -filter:v "setpts=1.035*PTS" -an video.stretched.mp4
# mux the stretched video with the audio:
ffmpeg -i video.stretched.mp4 -i audio.mp4 \
-c:v copy -c:a aac -strict experimental \
-map 0:v:0 -map 1:a:0 -shortest muxed.mp4 
# ALT solution is to mod video FPS to that of audio source; `-r 29.97`.